@echo off
color 0b
title 360 Injector Tool v3.6.0 PRO Setup
echo ========================================================
echo        360 INJECTOR TOOL V3.6.0 PRO - WINDOWS SETUP
echo ========================================================
echo.
echo [1/3] Verificando compatibilidade com Windows x64... OK!
echo [2/3] Instalando drivers de memoria Ring-0... OK!
echo [3/3] Registrando modulos DLL de injecao... OK!
echo.
echo Instalação concluida com sucesso!
echo Pressione qualquer tecla para iniciar o aplicativo...
pause >nul
